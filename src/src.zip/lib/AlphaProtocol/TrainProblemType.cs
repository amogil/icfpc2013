﻿namespace lib.AlphaProtocol
{
	public enum TrainProblemType
	{
		Any,
		Simple,
		Fold,
		Tfold,
		Bonus42,
		Bonus137,
	}
}