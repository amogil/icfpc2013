namespace lib.Web
{
	public class EvalResponse
	{
		public string message;
		public string[] outputs;
		public string status;
	}
}