namespace lib.Web
{
	public class GuessResponse
	{
		public string status;
		public string[] values;
		public string message;
	}
}