namespace lib.Web
{
	public class EvalRequest
	{
		public string[] arguments;
		public string id;
		public string program;
	}
}