namespace lib.Web
{
	public class GuessRequest
	{
		public string id;
		public string program;
	}
}